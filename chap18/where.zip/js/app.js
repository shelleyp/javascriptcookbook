 window.onload=function() {
   document.getElementById("getmap").onclick=geoFindMe;
 }

